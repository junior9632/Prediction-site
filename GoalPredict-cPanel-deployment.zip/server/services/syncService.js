'use strict';

/**
 * SYNC SERVICE — background data synchronisation.
 *
 * Allowed to run automatically (cron / internal scheduler):
 *   fixtures, odds, statistics, results.
 *
 * FORBIDDEN here, by design: creating or publishing a prediction ticket.
 * This module deliberately does not import ticketService at all — ticket
 * generation is reachable only from an authenticated admin action.
 */

const db = require('../database/queries');
const time = require('../utils/time');
const logger = require('../utils/logger');
const settingsService = require('./settingsService');
const fixtureService = require('./fixtureService');
const oddsService = require('./oddsService');
const statsService = require('./statsService');
const resultService = require('./resultService');
const logService = require('./logService');
const { ApiFootballUnavailable, apiFootball: defaultApi } = require('./apiFootball');

const log = logger.child('sync');

/** Keep the model inputs (team form + league environment) up to date. */
async function refreshModelInputs(ticketDate, options = {}) {
  const settings = options.settings || (await settingsService.getEngineSettings());
  const api = options.api || defaultApi;
  const start = time.startOfUtcDay(ticketDate);
  const end = time.addDays(start, 1);
  const fixtures = await db.getPlayableFixturesBetween(start, end, settings.syncLeagues.length ? settings.syncLeagues : null);

  const teamIds = new Set();
  const leagueIds = new Set();
  for (const f of fixtures) {
    if (f.home_team_id) teamIds.add(Number(f.home_team_id));
    if (f.away_team_id) teamIds.add(Number(f.away_team_id));
    if (f.league_id) leagueIds.add(Number(f.league_id));
  }

  // Form is always computed STRICTLY BEFORE the ticket date, so a fixture can
  // never see its own day's results (no future-data leakage).
  await statsService.refreshTeamForms([...teamIds], {
    before: start,
    windows: [5, Number(settings.formWindowMatches) || 10],
  });

  let leagueRefreshed = 0;
  for (const leagueId of leagueIds) {
    // eslint-disable-next-line no-await-in-loop
    await statsService.refreshLeagueEnvironment(leagueId, { before: start });
    leagueRefreshed += 1;
  }

  // optional head-to-head enrichment for the day's fixtures (bounded)
  let h2hCalls = 0;
  if (settings.enableH2hApi && api && api.configured && api.isAvailable()) {
    const limit = Math.min(fixtures.length, Number(options.h2hLimit) || 40);
    for (const f of fixtures.slice(0, limit)) {
      if (!f.home_team_id || !f.away_team_id) continue;
      try {
        // eslint-disable-next-line no-await-in-loop
        await statsService.syncH2HFromApi(Number(f.home_team_id), Number(f.away_team_id), { api, last: 6, now: new Date() });
        h2hCalls += 1;
      } catch (err) {
        if (err instanceof ApiFootballUnavailable) {
          log.warn('h2h enrichment stopped: API unavailable');
          break;
        }
        log.warn('h2h enrichment failed', { fixtureId: f.id, message: err.message });
      }
    }
  }

  return { teams: teamIds.size, leagues: leagueRefreshed, fixtures: fixtures.length, h2hCalls };
}

/**
 * The calendar day the sync jobs call "today", as observed in `sync_timezone`.
 *
 * Storage is always UTC; this only decides which API day windows are pulled, so
 * a host whose operators work in, say, Africa/Lagos stops syncing "yesterday"
 * during the last hour of their evening. `sync_timezone` defaults to `UTC`,
 * which reproduces the original behaviour exactly. An unknown zone is reported
 * and falls back to UTC rather than silently moving the window.
 */
function resolveSyncZone(settings = {}) {
  const requested = String(settings.syncTimezone || 'UTC').trim() || 'UTC';
  if (time.isValidTimeZone(requested)) return { zone: requested, valid: true };
  log.warn('sync_timezone is not a known timezone — falling back to UTC', { requested });
  return { zone: 'UTC', valid: false, requested };
}

/** The date anchor for a sync run: UTC midnight of the zone's calendar day. */
function syncAnchor(now, zone) {
  return time.zoneDateAnchor(now || new Date(), zone) || time.startOfUtcDay(now || new Date());
}

/** Fixtures for today + the configured number of days ahead (+ history). */
async function syncFixtures(options = {}) {
  const settings = options.settings || (await settingsService.getEngineSettings());
  const api = options.api || defaultApi;
  const trigger = options.trigger || 'manual';
  const handle = await logService.startSync('fixtures', trigger);

  try {
    const { zone, valid, requested } = resolveSyncZone(settings);
    const anchor = syncAnchor(options.now, zone);
    const upcoming = await fixtureService.syncUpcoming({
      api,
      daysAhead: Number(settings.syncDaysAhead) || 2,
      leagueIds: settings.syncLeagues.length ? settings.syncLeagues : null,
      now: anchor,
    });

    let history = { rowsWritten: 0, endpointCalls: 0 };
    if (options.includeHistory !== false) {
      history = await fixtureService.syncHistory({
        api,
        days: Number(settings.syncHistoryDays) || 25,
        leagueIds: settings.syncLeagues.length ? settings.syncLeagues : null,
        now: anchor,
      });
    }

    const modelInputs = await refreshModelInputs(anchor, { settings, api });

    await logService.finishSync(handle, {
      status: 'SUCCESS',
      endpointCalls: upcoming.endpointCalls + history.endpointCalls,
      rowsWritten: upcoming.rowsWritten + history.rowsWritten,
      message: `upcoming=${upcoming.rowsWritten} history=${history.rowsWritten} teams=${modelInputs.teams} leagues=${modelInputs.leagues} tz=${zone}${valid ? '' : ` (unknown: ${requested})`}`,
    });
    return {
      job: 'fixtures',
      upcoming: upcoming.rowsWritten,
      history: history.rowsWritten,
      endpointCalls: upcoming.endpointCalls + history.endpointCalls,
      syncTimezone: zone,
      syncTimezoneValid: valid,
      syncedFromDate: time.toMysqlDate(anchor),
      modelInputs,
    };
  } catch (err) {
    await logService.finishSync(handle, {
      status: 'FAILED',
      errorDetail: err.message,
      message: err instanceof ApiFootballUnavailable ? 'DATA SOURCE TEMPORARILY UNAVAILABLE' : 'fixture sync failed',
    });
    if (err instanceof ApiFootballUnavailable) return { job: 'fixtures', status: 'DATA_SOURCE_UNAVAILABLE', error: err.message };
    throw err;
  }
}

/** Odds for today + days ahead. One bulk request per page per date. */
async function syncOdds(options = {}) {
  const settings = options.settings || (await settingsService.getEngineSettings());
  const api = options.api || defaultApi;
  const trigger = options.trigger || 'manual';
  const handle = await logService.startSync('odds', trigger);

  try {
    const days = Number(settings.syncDaysAhead) || 2;
    const { zone, valid, requested } = resolveSyncZone(settings);
    const anchor = syncAnchor(options.now, zone);
    let totalRows = 0;
    let totalCalls = 0;
    const perDate = [];
    const skipped = [];
    for (let i = 0; i <= days; i += 1) {
      const date = time.addDays(anchor, i);
      let res;
      try {
        // eslint-disable-next-line no-await-in-loop
        res = await oddsService.syncOddsForDate(date, {
          api,
          settings,
          maxPages: Number(settings.oddsSyncMaxPages) || 12,
          now: options.now,
        });
      } catch (err) {
        // A single date being rejected (e.g. no odds window for it) must not
        // throw away the dates that do work. Credential problems, quota and
        // outages still abort the whole job. Any non-auth 4xx rejection is
        // treated as specific to that date, even when the provider (or an older
        // client) omits the structured `reason` field.
        const d = (err && err.details) || {};
        const status = Number(d.status);
        const authRejected = status === 401 || status === 403;
        const dateOnlyRejection =
          err instanceof ApiFootballUnavailable &&
          !authRejected &&
          Number.isFinite(status) &&
          status >= 400 &&
          status < 500;
        if (!dateOnlyRejection) throw err;
        log.warn('odds sync skipped a date rejected by the provider', { date: time.toMysqlDate(date), message: err.message });
        skipped.push({ date: time.toMysqlDate(date), error: err.message, details: d });
        continue;
      }
      totalRows += res.rowsWritten;
      totalCalls += res.endpointCalls;
      perDate.push(res);
    }
    if (!perDate.length && skipped.length) {
      const first = skipped[0] || {};
      const firstDetails = first.details || {};
      throw new ApiFootballUnavailable(first.error || 'API-Football request rejected', {
        reason: 'REQUEST_REJECTED',
        status: firstDetails.status || null,
        endpoint: firstDetails.endpoint || null,
        errors: firstDetails.errors || null,
        hint: firstDetails.hint || null,
        skipped,
      });
    }
    await logService.finishSync(handle, {
      status: 'SUCCESS',
      endpointCalls: totalCalls,
      rowsWritten: totalRows,
      message: `dates=${perDate.length} rows=${totalRows} tz=${zone}${valid ? '' : ` (unknown: ${requested})`}${skipped.length ? ` skipped=${skipped.length}` : ''}`,
    });
    return {
      job: 'odds',
      skippedDates: skipped,
      rowsWritten: totalRows,
      endpointCalls: totalCalls,
      syncTimezone: zone,
      syncTimezoneValid: valid,
      perDate,
    };
  } catch (err) {
    await logService.finishSync(handle, {
      status: 'FAILED',
      errorDetail: err.message,
      message: err instanceof ApiFootballUnavailable ? 'DATA SOURCE TEMPORARILY UNAVAILABLE' : 'odds sync failed',
    });
    if (err instanceof ApiFootballUnavailable) {
      const d = err.details || {};
      return {
        job: 'odds',
        status: 'DATA_SOURCE_UNAVAILABLE',
        error: err.message,
        ...(d.reason ? { reason: d.reason } : {}),
        ...(d.status ? { httpStatus: d.status } : {}),
        ...(d.hint ? { hint: d.hint } : {}),
      };
    }
    throw err;
  }
}

/** Final scores + settlement of pending picks. */
async function syncResults(options = {}) {
  const settings = options.settings || (await settingsService.getEngineSettings());
  const api = options.api || defaultApi;
  const trigger = options.trigger || 'manual';
  const handle = await logService.startSync('results', trigger);

  try {
    const { zone, valid, requested } = resolveSyncZone(settings);
    const anchor = syncAnchor(options.now, zone);
    const res = await resultService.syncResults({
      api,
      days: Number(options.days) || Math.min(7, Number(settings.syncHistoryDays) || 7),
      now: anchor,
      settings,
    });
    await logService.finishSync(handle, {
      status: 'SUCCESS',
      endpointCalls: res.endpointCalls,
      rowsWritten: res.resultsRecorded + res.selectionsSettled,
      message: `results=${res.resultsRecorded} settled=${res.selectionsSettled} tickets=${res.ticketsUpdated} tz=${zone}${valid ? '' : ` (unknown: ${requested})`}`,
    });
    return { job: 'results', syncTimezone: zone, syncTimezoneValid: valid, ...res };
  } catch (err) {
    await logService.finishSync(handle, {
      status: 'FAILED',
      errorDetail: err.message,
      message: err instanceof ApiFootballUnavailable ? 'DATA SOURCE TEMPORARILY UNAVAILABLE' : 'result sync failed',
    });
    if (err instanceof ApiFootballUnavailable) return { job: 'results', status: 'DATA_SOURCE_UNAVAILABLE', error: err.message };
    throw err;
  }
}

/** Run every allowed sync job in sequence (used by cron scripts). */
async function syncAll(options = {}) {
  const results = {};
  results.fixtures = await syncFixtures(options);
  results.odds = await syncOdds(options);
  results.results = await syncResults(options);
  const unavailable = Object.values(results).some((r) => r && r.status === 'DATA_SOURCE_UNAVAILABLE');
  return { ...results, dataSourceAvailable: !unavailable };
}

/** Health / quota information for the admin "API Status" panel. */
async function getApiStatus(options = {}) {
  const api = options.api || defaultApi;
  const breaker = api.breakerState();
  let quota = breaker.quota;
  let plan = null;
  if (api.configured && api.isAvailable() && options.probe !== false) {
    try {
      const status = await api.getStatus();
      if (status) {
        quota = status.requests ? { current: status.requests.current, limit_day: status.requests.limit_day } : quota;
        plan = {
          subscription: status.subscription ? status.subscription.name || status.subscription.plan : null,
          active: Boolean(status.active ?? true),
        };
      }
    } catch (err) {
      log.warn('api status probe failed', { message: err.message });
    }
  }
  const syncs = await logService.recentSyncs(12);
  return {
    configured: api.configured,
    keyConfigured: api.configured, // never expose the key itself
    ...breaker,
    quota,
    plan,
    host: api.host,
    recentSyncs: syncs.map((s) => ({
      id: Number(s.id),
      job: s.job,
      status: s.status,
      trigger: s.trigger_source,
      message: s.message,
      durationMs: s.duration_ms === null ? null : Number(s.duration_ms),
      startedAt: s.started_at,
    })),
  };
}

module.exports = { syncFixtures, syncOdds, syncResults, syncAll, refreshModelInputs, getApiStatus };
