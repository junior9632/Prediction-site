# GoalPredict — Unfinished modules (inventory of build code)

**Repository:** `junior9632/Prediction-site`
**Analysed revision:** `main` @ `ef547d4` (checked out as `arena/d1c5e8d0-prediction-site`)
**Date:** 2026-10-08

### How this list was produced

| Check | Tool / command | Result |
| --- | --- | --- |
| Test suite | `npm test` | 124/124 pass, 0 skipped, 0 todo |
| Documented endpoints vs. mounted routes | `docs/API.md` ∩ `server/routes/*.js` | no drift |
| Frontend `API.*` calls vs. server routes | `public/js/*.js` ∩ `server/routes/*.js` | no drift |
| Schema tables vs. SQL actually issued | `schema.sql` ∩ `queries.js` | 17/17 tables used |
| Settings declared vs. settings consumed | `settingsService.js` `DEFINITIONS` ∩ `server/` | **3 were inert — fixed in module 3** |
| Deployment artefact vs. source | `GoalPredict-cPanel-deployment.zip` ∩ working tree | **28 of 115 files stale** |
| Unmerged work | `git ls-tree` `main` vs. `origin/pr#5` | **8 files + 8 npm scripts missing** |

Everything else in the repository is wired: no `TODO`/`FIXME`/`not implemented` markers exist
anywhere in the source, and every page, route, controller, service and script that `main`
ships has a caller.

---

## 1. Unfinished = built but NOT merged into `main` (open PR #5)

These modules exist as working code on the open pull request
`#5 — "Dashboard Activity is only visible to logged-in users (server-protected)"`
(branch `arena/02873d40-prediction-site`). None of them are in `main` today.

> **Progress — module 1 § 1–6 is now COMPLETE on `arena/d1c5e8d0-prediction-site`**
> (rebased onto `main`, written against the post-PR-#6 odds integrity code instead of merging
> PR #5 wholesale). See section 5 below for the delivered implementation.

| # | Module name | Build code (files) | What it does |
| --- | --- | --- | --- |
| 1 | **Member Dashboard Activity API** | `server/routes/dashboard.js` | `GET /api/dashboard/activity`, `requireAuth` + `requireActiveAccount`, 401 for guests |
| 2 | **Member Dashboard controller** | `server/controllers/dashboardController.js` | caller-scoped activity payload |
| 3 | **Member Activity service** | `server/services/activityService.js` | activity feed built from `system_logs`, scoped to the signed-in principal, max 25 items |
| 4 | **Active-account guard middleware** | `server/middleware/account.js` | re-reads the account row per request → `ACCOUNT_MISSING` / `ACCOUNT_DISABLED` / `ACCOUNT_LOCKED` |
| 5 | **Dashboard activity test suite** | `tests/dashboard-activity.test.js` | pins guest 401, forged-token 401, member scoping, disabled account 403, admin perms |
| 6 | **Homepage render test suite** | `tests/homepage-render.test.js` | pins that public pages carry no private/dashboard markup |
| 7 | **Deployment doctor script** | `scripts/doctor.js` (+ npm `doctor`) | env / MySQL / schema / seed / guest-boundary diagnosis, exit 1 on fault |
| 8 | **Access verifier script** | `scripts/verify-access.js` (+ npm `verify:access`) | proves guest / member / admin boundary against a **running** deployment |

Unmerged supporting changes that ship in the same PR:

* **Public homepage redesign** — `public/index.html`, `public/js/app.js`, `public/css/style.css`
  (+198 CSS lines: five-item mobile bar, sports-intelligence landing layout).
* **Admin sign-in door + DB-fault diagnostics** — `server/app.js`,
  `server/controllers/authController.js`, `public/js/api.js`, `public/account.html`,
  `public/js/account.js`.
* **Member sign-in landing / session hardening** — `no-store` session responses, disabled
  accounts refused in `/api/auth/me`, bfcache revalidation.
* **Queries & fakeDb additions** — `server/database/queries.js` (+23 lines, actor-scoped
  `system_logs` reads), `tests/fakeDb.js`, `tools/uipreview.js` demo member.

> **Merge blocker:** PR #5 branched before PR #6 and is **behind `main`**. It is missing
> `server/database/migrations/001-widen-odds-precision.sql` and `tests/review.test.js`, and its
> copies of `server/prediction/over15.js`, `server/prediction/risk.js`,
> `server/prediction/ticketBuilder.js`, `server/utils/decimal.js`, `server/services/oddsService.js`
> and `server/services/ticketService.js` are the **pre-odds-integrity-fix** versions. It needs a
> rebase before it can be merged.

---

## 2. Unfinished = half-built and still inside `main`

### 2a. Member activity feed — advertised in the UI, absent on the server — ✅ RESOLVED (module 1)

`public/dashboard.html` and `public/js/dashboard.js` are live and guarded by
`server/app.js` (`/dashboard`, `/dashboard.html`), and the page copy promises
*"Your account, prediction activity and the latest platform updates in one place."*

There is **no** `server/routes/dashboard.js`, no `dashboardController`, no `activityService` and
no `/api/dashboard/*` mount in `main` — the module that fulfils that promise is items 1–4 above.

### 2b. Inert settings — ✅ RESOLVED (module 3)

The first scan flagged five settings. Tracing each one's real engine mapping showed **three were
genuinely inert**; the other two were already live under irregular names
(`odds_reverify_before_generation` → `reverifyOddsBeforeGeneration`,
`confidence_weights` → `confidence`). All three real gaps are now wired and enforced — see
module 3 in § 5.

### 2c. Stale build artefact — `GoalPredict-cPanel-deployment.zip`

**Resolved in module 4** — see § 5. The tracked deployment ZIP was not the build of the current
source:

* **28 of its 115 files differ** from the working tree — including `README.md`,
  `docs/DEPLOYMENT-CPANEL.md`, `public/index.html`, `public/js/app.js`, `public/js/dashboard.js`,
  `server/app.js`, `server/database/schema.sql`, `server/prediction/over15.js`,
  `server/prediction/risk.js`, `server/prediction/ticketBuilder.js`, `server/utils/decimal.js`,
  `server/services/oddsService.js`, `server/services/ticketService.js`, `tests/acceptance.test.js`.
* It **does not contain** `server/database/migrations/001-widen-odds-precision.sql`
  or `tests/review.test.js`.
* It predates the admin-hardening work, so deploying it would ship the old public surface.

---

## 3. Previously-unfinished modules (already completed — reference naming)

The names used in the earlier "Complete unfinished modules" work (merged PR #2), kept here so the
list above can be compared like-for-like. All of these are **done** and present in `main`:

| Module | Build code | State |
| --- | --- | --- |
| Notification service (Telegram + webhook) | `server/services/notifyService.js` | complete |
| Legal / responsible-gambling + SEO | `public/legal.html`, `server/app.js` (`/robots.txt`, `/sitemap.xml`) | complete |
| Versioned DB migrations | `server/database/migrate.js`, `server/database/migrations/` | complete |
| ESLint + CI | `eslint.config.js`, `.github/workflows/checks.yml` | complete |
| Docker Compose local stack | `docker-compose.yml` | complete |
| Member accounts | `public/account.html`, `public/js/account.js`, `server/controllers/authController.js` | complete |
| PWA | `public/manifest.webmanifest`, `public/sw.js`, `public/offline.html` | complete |
| Analytics page | `public/analytics.html`, `public/js/analytics.js`, `server/services/analyticsService.js` | complete |

---

## 5. Progress log

### Module 1 — Member Dashboard Activity — ✅ COMPLETE (`arena/d1c5e8d0-prediction-site`)

Delivered, tested and documented:

| Piece | File |
| --- | --- |
| Active-account guard middleware | `server/middleware/account.js` **new** |
| Member Activity service | `server/services/activityService.js` **new** |
| Member dashboard controller | `server/controllers/dashboardController.js` **new** |
| Member dashboard routes (`/api/dashboard`) | `server/routes/dashboard.js` **new** |
| Actor-scoped audit queries | `server/database/queries.js` (+`listActorSystemLogs`, `countActorSystemLogs`) |
| Route mount + hardened member page guard | `server/app.js` |
| `no-store` on every session response | `server/routes/auth.js` |
| Explicit actors on login events, guarded `/me` | `server/controllers/authController.js` |
| Dashboard Activity card + renderer | `public/dashboard.html`, `public/js/dashboard.js` |
| Member → dashboard link | `public/account.html` |
| Preview harness: demo member + seeded activity | `tools/uipreview.js` (`member` / `preview123`) |
| Test suite (10 tests) | `tests/dashboard-activity.test.js` **new** |
| Docs | `README.md`, `docs/API.md`, `docs/ARCHITECTURE.md` |

Verification: `npm test` 124/124 · `npm run test:sql` 17 tables / 84 statements · `lint:secrets`
26 files clean · `lint:syntax` clean · ESLint clean.

### Module 5 — Public homepage redesign — ✅ COMPLETE

The public homepage is now a sports-intelligence landing page built from **public data only**, in
the direction PR #5 sketched, but written against the post-odds-integrity code rather than merging
the stale branch.

| Piece | File |
| --- | --- |
| Landing layout: hero + eyebrow + dual CTA + trust strip | `public/index.html` |
| Live "today's ticket" panel (status pill, odds, picks, confidence, generated-at / honest reason) | `public/index.html` + `public/js/app.js` |
| Today's Accumulator card kept and repainted from real data | `public/js/app.js` |
| Rules cards, latest settled tickets, 18+ / responsible-play footer | `public/index.html` |
| Design system additions (`hp-hero`, `hp-eyebrow`, `hp-h1`, `hp-cta`, `hp-trust`, `hp-live`, `hp-pill` + small-screen rules) | `public/css/style.css` |
| Render contract suite (6 tests) | `tests/homepage-render.test.js` **new** |

The page reads `/api/ticket/today` and `/api/tickets/history?limit=5` — the same two public
endpoints every visitor may read. It never references `/api/dashboard`, `activityFeed`,
`/js/dashboard.js`, `/api/admin` or the admin surface, which is asserted both statically
(`tests/homepage-render.test.js`) and against the running app (`verify-access` guest checks).

Honesty rules the page obeys: a dead feed renders "Data offline" (red pill) rather than a stale
ticket, a no-ticket day renders the reason plus the full diagnostics grid, a browser-side failure
says "Status unavailable" instead of blaming the feed, and no copy promises a win.

### Module 6 — Re-audit after modules 1–5 — ✅ COMPLETE

Re-ran every check from the original inventory against the delivered tree (see § 6).

### Remaining modules

| # | Module | State |
| --- | --- | --- |
| 2 | Admin sign-in door `/admin/login` | ✅ done (module 2) |
| 3 | `scripts/doctor.js` deployment diagnosis | ✅ done (module 2) |
| 4 | `scripts/verify-access.js` deployment verifier | ✅ done (module 2) |
| 5 | Inert settings wired up | ✅ done (module 3) |
| 6 | Deployment ZIP regenerated + drift-proofed | ✅ done (module 4) |
| 7 | Homepage redesign (`index.html`, `js/app.js`, `css/style.css`) + `tests/homepage-render.test.js` | ✅ done (module 5, reworked in module 7) |
| — | Re-audit after modules 1–5 | ✅ done (module 6) |

### Module 4 — Deployment artefact — ✅ COMPLETE

| Piece | File |
| --- | --- |
| Deterministic ZIP builder (pure Node, `zlib` + a small ZIP writer) | `scripts/build-deployment-zip.js` **new** |
| `npm run build:zip` and `--check` | `package.json` |
| Drift guard — fails when the committed ZIP is not the build of the committed tree | `tests/deployment-zip.test.js` **new** |
| Regenerated archive (128 files) | `GoalPredict-cPanel-deployment.zip` |
| Docs | `README.md`, `docs/DEPLOYMENT-CPANEL.md` |

### Module 3 — Inert settings — ✅ COMPLETE

| Gap | Fix |
| --- | --- |
| `combination_weights` never reached the builder | forwarded by `prediction/pipeline.js` into `ticketBuilder.buildTicket()` |
| `combination_leg_penalty` never reached the builder | same — forwarded as `legPenalty` |
| `results_settle_mode` was a dead row | `resultService.assertSettleMode()` enforces it on every settlement; an unsupported value stops the run with `SETTLE_MODE_UNSUPPORTED` instead of settling against the wrong scoreline, and `syncResults()` reports `settleMode` |
| `sync_timezone` was a dead row | `utils/time.js` gains `isValidTimeZone` / `dateInZone` / `zoneDateAnchor`; `syncService` anchors every sync run on the operator's calendar day (UTC storage kept, `UTC` default byte-identical, unknown zone logged + UTC fallback) and returns `syncTimezone` / `syncTimezoneValid` |

| Piece | File |
| --- | --- |
| Zone helpers | `server/utils/time.js` |
| Combination weights + leg penalty forwarded | `server/prediction/pipeline.js` |
| Settlement mode enforced | `server/services/resultService.js` |
| Sync anchored on the configured day | `server/services/syncService.js` |
| Test suite (12 tests, incl. an inert-settings guard) | `tests/settings-wiring.test.js` **new** |
| Docs | `README.md`, `docs/ARCHITECTURE.md` |

### Module 2 — Operator & deployment readiness — ✅ COMPLETE

| Piece | File |
| --- | --- |
| Console sign-in door `/admin/login` + `/admin/login.html` | `server/app.js` |
| Console guard + client redirects now target the door | `server/app.js`, `public/js/admin.js` |
| Deployment doctor (`npm run doctor`) | `scripts/doctor.js` **new** |
| Live access verifier (`npm run verify:access`) | `scripts/verify-access.js` **new** |
| npm scripts | `package.json` |
| `AbortSignal` global for the ESLint env | `eslint.config.js` |
| Existing admin-redirect assertions updated to the door | `tests/http.test.js` |
| Script wiring + failure-mode tests | `tests/scripts.test.js` |
| Live-verifier + door assertions | `tests/dashboard-activity.test.js` |
| Docs | `README.md`, `docs/API.md`, `docs/DEPLOYMENT-CPANEL.md` |

Verified against the running app: `verify-access` **35/35 checks pass**; `doctor` exits 1 on a
broken database while naming the cause and the fix and never printing a secret.

---

## 4. Suggested order of work

1. ~~Rebase and merge PR #5~~ — **superseded.** Every module PR #5 carried has been rebuilt on
   top of `main` (modules 1–5 above) against the post-odds-integrity engine. PR #5 should be
   **closed**, not merged: its copies of `over15.js`, `risk.js`, `ticketBuilder.js`,
   `decimal.js`, `oddsService.js` and `ticketService.js` predate the odds-integrity fix, and
   merging it now would revert that work.
2. ~~Wire or delete the inert settings~~ — **done** (module 3).
3. ~~Regenerate `GoalPredict-cPanel-deployment.zip`~~ — **done** (module 4), and the archive can
   no longer silently drift: `npm test` fails when it is not the build of the committed tree.
4. Deploy from the regenerated archive and prove the host with `npm run doctor` and
   `npm run verify:access -- --member=… --admin=…`.

---

## 6. Re-audit results (module 6)

Run after modules 1–5 landed, against the delivered tree (`npm test` **130/130**).

| Check | How | Result |
| --- | --- | --- |
| Mounted routes vs `docs/API.md` | `server/routes/*.js` ∩ `app.use` prefixes vs the documented endpoint rows | **42 route pairs; all documented.** The two alias combinations (`GET /api/tickets/today`, `GET /api/ticket/history`) were implicit — the double mount is now spelled out in the API doc |
| Documented endpoints with no route | `docs/API.md` → mounted routes | **none** |
| Frontend calls vs routes | 31 `API.*` calls in `public/js/*.js` | **no drift** — every call resolves to a mounted route |
| Settings declared vs consumed | `tests/settings-wiring.test.js` (`CONSUMED_AS`) | **PASS** — 51 declared settings, no inert row |
| Schema vs SQL issued | `npm run test:sql` | **PASS** — 17 tables / 84 statements |
| Deployment artefact vs source | `npm run build:zip -- --check` | **PASS** — 129 files, byte-identical to the committed tree (`--check` reports it up to date) |
| Public surface leaks | every `public/*.html` except `admin.html` | **none** — no `/api/admin`, no `/api/dashboard`, no `data-auth-admin`, no admin script |
| Orphaned pages / scripts / assets | links in every page + `app.js` + `sw.js` | **none** — every page is linked, every referenced asset exists, every script is loaded |
| `TODO` / `FIXME` / "not implemented" markers | `server/`, `public/`, `scripts/`, `tests/` | **none** |
| Docs consistency fixes found by the audit | — | `README.md` test count (124 → 130), CI job order (missing `lint:js`), homepage description; `docs/API.md` ticket alias mount |

**New work introduced by the audit:** none. Both findings were documentation drift, not missing
functionality, and both are fixed in the same commit as module 5.

### Module 7 — Public homepage rebuilt as a pure landing page — ✅ COMPLETE

The homepage shipped in module 5 still carried live ticket widgets (a "today's ticket" panel, the
accumulator card, settled results). They were public data, but they made the homepage read like a
dashboard. Module 7 removes every data widget and replaces the page with a static marketing
landing page. The three experiences are now cleanly separated:

| Experience | Route | Content |
| --- | --- | --- |
| Public marketing | `/` (+ `/about`) | Static only: hero, trust strip, one-market section, daily target, process, features, CTA. **No** API call, no data widget, no admin reference |
| Member dashboard | `/dashboard` | Authenticated: profile, status, account activity, prediction history (unchanged) |
| Operator console | `/admin` | Private: guarded by `/admin/login` (unchanged) |

| Piece | File |
| --- | --- |
| Landing page (hero → trust → what → market → target → process → why → CTA → footer) | `public/index.html` |
| About page | `public/about.html` **new** |
| Marketing-only script: drawer, reveal-on-scroll, session-aware header — zero API calls | `public/js/app.js` |
| Landing design layer (`lp-*`: header, hero + pitch artwork, trust cards, split panels, market, target, timeline, features, CTA, footer, 3 breakpoints) | `public/css/style.css` |
| Session-aware header helpers (`data-auth-register`, mobile chips) | `public/js/api.js` |
| `/about` route, `/login` now serves the member sign-in, `/about` in the sitemap | `server/app.js` |
| `#terms` / `#privacy` anchors for the footer links | `public/legal.html` |
| Acceptance suite (7 tests) incl. the "anonymous visitor sees no dashboard" contract | `tests/homepage-render.test.js` |
| Nav / bottom-bar assertions updated to the new public navigation | `tests/http.test.js` |
| Docs | `README.md`, `docs/API.md`, `docs/DEPLOYMENT-CPANEL.md` |

The forbidden-widget check is explicit: the suite fails if the homepage ever renders a ticket,
odds, accumulator, statistics or privileged hook again (`accSummary`, `pickList`, `liveOdds`,
`recentResults`, `/api/ticket`, `/api/dashboard`, `/api/admin`, …), and `js/app.js` is asserted to
contain no `API.*` call, no `fetch` and no `XMLHttpRequest` at all.

### Module 8 — Homepage becomes a sports-intelligence page with a PUBLIC preview — ✅ COMPLETE

Module 7 made the homepage purely static, which was honest but left a visitor with nothing to look
at. Module 8 gives it a public preview built strictly from endpoints a guest can already read, and
tightens the public/private boundary with tests that run the real script.

| Surface | Source | Who can read it |
| --- | --- | --- |
| Today's published selection (status, picks, total odds, model probability, generated-at) | `GET /api/ticket/today` | Everyone — same payload as `/ticket` |
| The published record (settled tickets, ticket win rate, Over 1.5 leg win rate, flat-stake ROI) | `GET /api/analytics` | Everyone — same payload as `/analytics` |
| Today's analysed fixtures as match cards (league, teams, kickoff, model probability, xG, verified price) | `GET /api/predictions?limit=6` | Everyone — same payload as `/predictions` |
| Dashboard activity, account statistics, personal history | `GET /api/dashboard/activity` | 401 for guests, own data only for a signed-in member |

| Piece | File |
| --- | --- |
| Landing page: hero (AI Sports Intelligence badge) + preview panel + record tiles + match cards + trust/market/target/process/features/CTA | `public/index.html` |
| Public-preview renderer (pills, honest empty states, `verifiedChip` reuse) — public endpoints only | `public/js/app.js` |
| Preview layer (`pv-panel`, `pv-pill`, `pv-tiles`, `pv-match`, `pv-metric`) + 3 breakpoints | `public/css/style.css` |
| Nav per the brief: Home · Today's Predictions (`/ticket`) · Matches (`/predictions`) · Analytics, with Login + Create Account | `public/index.html` |
| Contract suite (9 tests), including an executed-script request trace | `tests/homepage-render.test.js` |
| Primary-nav assertion updated | `tests/http.test.js` |
| Docs | `README.md` (public page vs dashboard), `docs/API.md` |

The boundary is enforced in three layers, none of them cosmetic:

1. **Server** — `/api/dashboard/*` runs `requireAuth` → `requireActiveAccount` and scopes every
   query to the session's own account; the page guard redirects guests to `/account.html`.
   (Proved by `tests/dashboard-activity.test.js` and, live, by `npm run verify:access`.)
2. **Static contract** — the homepage markup and script may not contain `/api/dashboard`,
   `/api/admin`, `activityFeed`, `dashboard.js` or any account-scoped vocabulary, and the endpoint
   map in `public/js/app.js` must equal the public preview set exactly.
3. **Runtime contract** — the suite boots the real `api.js` + `app.js` in a DOM harness with a
   recording `fetch`: the recorded requests must be exactly `/api/auth/me` plus the three public
   endpoints, and the preview must actually paint from those payloads.

Live verification: guest `/api/dashboard/activity` → `401` with no data; guest `/dashboard` and
`/dashboard.html` → `302 /account.html`; member session → `200`, `scope: self`, own account only;
guest `/admin` → `302 /admin/login`; admin console unchanged; `verify-access` **35/35**.

---

### Module 9 — Football predictions become LOGIN ONLY — ✅ COMPLETE

Module 8 deliberately published today's selection, the record and the analysed fixtures on the
landing page "because a guest could already read them on `/ticket`, `/analytics` and
`/predictions`". Module 9 inverts that premise: **the football surfaces themselves are now member
only**, so the landing page has nothing left to mirror and becomes pure marketing.

| Surface | Before | After |
| --- | --- | --- |
| `/api/predictions`, `/api/predictions/:id` | public | **member** — 401 + empty body for a guest |
| `/api/ticket/today`, `/api/ticket/:date`, `/api/tickets/*` | public | **member** |
| `/api/analytics` | public | **member** |
| `/api/fixtures`, `/api/odds` | public | **member** (they carry the verified Over 1.5 price and the fixture's confidence) |
| `/predictions`, `/ticket`, `/today-ticket`, `/history`, `/analytics` (+ `.html`) | public | **member** — 401 + the "login required" page, `no-store`, `noindex` |
| `/`, `/about`, `/legal`, `/login`, `/account`, `/api/health`, `/api/meta` | public | unchanged |

| Piece | File |
| --- | --- |
| `memberGuard = [noStore, requireAuth, requireActiveAccount]` — the dashboard's own guard, reused | `server/middleware/account.js` |
| `router.use(memberGuard)` on every prediction router (both `/api/ticket` and `/api/tickets` aliases) | `server/routes/{predictions,tickets,analytics,fixtures,odds}.js` |
| `memberAreaGuard(section)` + the `/today-ticket` alias, registered **before** `express.static` so the `.html` aliases are guarded too | `server/app.js` |
| Server-rendered refusal (outside `public/`, so it is never a fetchable asset) | `server/views/login-required.html` |
| Lock-preview styles | `public/css/style.css` (`.lock-*`, `.lock-mask`) |
| Landing page: locked preview, member-only nav, unlock CTAs, no data fetch | `public/index.html`, `public/js/app.js` |
| Member-only navigation revealed only after `/api/auth/me`; a 401 walks the browser to `/login?next=…` | `public/js/api.js` |
| `?next=` honoured on sign-in and registration (same-site paths only) | `public/js/account.js` |
| Nav / footer / mobile drawer on every public page | `index.html`, `about.html`, `legal.html`, `account.html`, `login.html`, `predictions.html`, `ticket.html`, `history.html`, `analytics.html`, `dashboard.html` |
| Acceptance matrix (19 tests) | `tests/predictions-auth.test.js` |
| Public-side contract rewritten for the locked homepage (10 tests) | `tests/homepage-render.test.js` |
| Member reads, sitemap and primary-nav assertions updated | `tests/http.test.js` |
| Deployed-site matrix extended (guest APIs, guest pages, homepage, member APIs/pages, scope) | `scripts/verify-access.js` |
| Preview harness no longer serves the guarded pages, so the real guards run there too | `tools/uipreview.js` |
| Docs | `README.md`, `docs/API.md`, `docs/ARCHITECTURE.md`, `docs/DEPLOYMENT-CPANEL.md` |

Four layers, none of them cosmetic:

1. **Server** — the guard runs before any controller, query or template. The API answers `401`
   `{"ok":false,…}` with no `data` key and `Cache-Control: no-store`; a page answers `401` (or
   `403` for a disabled/locked account) with the login-required view, `no-store` and
   `X-Robots-Tag: noindex`. The account is **re-read from the database** on every request, so a
   deleted, deactivated or locked member is refused even while its JWT is still valid.
2. **Session-derived identity** — `requireAuth` verifies the token and `requireActiveAccount`
   resolves the principal. No handler reads a `userId`, `user_id`, `account` or `role` parameter
   and no `X-User-Id` header is consulted, so a forged id cannot widen the payload.
3. **Static contract** — the landing page's markup and script may not name any prediction
   endpoint, and every member-only navigation entry must ship `hidden`.
4. **Runtime contract** — the suite boots the real `api.js` + `app.js` in a DOM harness with a
   recording `fetch`: the recorded requests must be exactly `/api/auth/me`.

Live verification against the preview harness: `verify-access` **315/315** (guest 401 on 9 APIs and
9 pages with zero data leakage; member 200 on the same surfaces; admin console unchanged;
`npm test` **154/154**).

### Module 10 — Data-source failures name their cause (and stop burning the daily quota) — ✅ COMPLETE

Reported symptom: the admin activity panel showed `fixtures` and `odds` syncs **FAILED** with the
same sentence (`DATA SOURCE TEMPORARILY UNAVAILABLE`) while `results` reported **SUCCESS** with
zeros, and the last generation ended `DATA_SOURCE_UNAVAILABLE` with 0 picks — no way to tell a spent
daily quota from a rejected key, a provider outage or a blocked network, and no way to see how much
of the plan had been used.

| Root cause | Fix |
| --- | --- |
| Every upstream failure collapsed into one sentence | `UNAVAILABLE_REASONS` + `REASON_INFO` in `apiFootball.js`: `NO_API_KEY`, `CREDENTIAL_UNREADABLE`, `CIRCUIT_OPEN`, `QUOTA_EXCEEDED`, `QUOTA_RESERVED`, `RATE_LIMITED`, `AUTH_REJECTED`, `REQUEST_REJECTED`, `PROVIDER_UNAVAILABLE`, `NETWORK_ERROR`, `TIMEOUT` — each with an operator-facing label and the exact fix; `describeUnavailable()` / `unavailableMessage()` keep the documented headline and append the reason + reset time |
| The daily request budget was invisible | the client learns `x-ratelimit-requests-limit` / `-remaining` from every answer (and `/status`), exposes `quotaState()`, and every job persists it in `api_sync_logs` (`requests_used` / `requests_limit` — columns that existed but were never written) |
| A spent plan was retried like a transient outage | `QUOTA_EXCEEDED` is never retried, the client stops calling the data endpoints until 00:00 UTC (the free `/status` probe stays available) and `breakerState()` reports `QUOTA_EXHAUSTED` instead of `OPEN`; a spent day is not an upstream outage |
| Every cron run re-spent the budget: the backfill pulled all 25 history days every hour and head-to-head enrichment up to 40 fixtures | history re-requests only days older than `history_refresh_minutes` (360) and reports `skippedFresh`; H2H only runs while the local sample is below `h2h_min_meetings` (3), at most `h2h_sync_max_calls` (20) per run |
| Background sync could eat the requests a manual generation needs | `api_quota_reserve` (25): fixtures/odds/results log `SKIPPED` / `QUOTA_RESERVED` with 0 provider calls; because each cron entry point is a new process, the pause also reads the budget the previous run recorded in `api_sync_logs` (current UTC day only) |
| The console showed the state, never the cause | `adminController.overview` exposes `dataSource.{reason,label,hint,resetsAt}` + `recentSyncs[].{errorDetail,requestsUsed,requestsLimit}`; `public/js/admin.js` renders them (dashboard alert, activity rows, last-generation failure note); `/api/health` carries the same reason; `cron-sync-*.js` print one plain-language line (exit code 2 when the source is unusable); `cron-health-check.js` reports the reason and only alerts when the cause changes |
| Diagnosing it needed SSH and guesswork | `npm run api:check` (`scripts/api-check.js`) — one free `/status` request, masked credential, verdict, daily budget and fix, exit 1 when unusable; `npm run doctor` gained the `DATA SOURCE (API-FOOTBALL)` group (`--skip-probe` to skip the probe), and `--json` stays parseable |

| Piece | File |
| --- | --- |
| Reason vocabulary, quota tracker, probe + request guards | `server/services/apiFootball.js` |
| Quota pause/reserve, reason in every log and payload, incremental backfill, bounded H2H | `server/services/syncService.js`, `server/services/fixtureService.js` |
| Reason in the stored generation report | `server/services/ticketService.js` |
| Budget columns + incremental-history query | `server/database/queries.js` |
| Settings | `history_refresh_minutes`, `api_quota_reserve`, `h2h_sync_max_calls` (`server/services/settingsService.js`) |
| Console + health + CLI | `public/js/admin.js`, `public/js/admin-api-management.js`, `server/controllers/{adminController,healthController}.js`, `server/services/apiCredentialService.js`, `scripts/{api-check.js,doctor.js,cron-health-check.js,cron-sync-*}.js`, `scripts/lib/sync-output.js` |
| Tests (18) | `tests/data-source-reasons.test.js`; panel assertions in `tests/dashboard-activity.test.js`; CLI assertions in `tests/scripts.test.js` |
| Docs | `README.md` (diagnosis table, quota settings, acceptance row 16), `docs/ARCHITECTURE.md` §3.1/§3.2/§10, `docs/API.md`, `docs/DEPLOYMENT-CPANEL.md` §7/§10, `.env.example` |

The anti-fabrication contract is unchanged: when the source cannot be used the run still ends
`DATA SOURCE_UNAVAILABLE` with **no** ticket and **no** invented picks — it now says why.
